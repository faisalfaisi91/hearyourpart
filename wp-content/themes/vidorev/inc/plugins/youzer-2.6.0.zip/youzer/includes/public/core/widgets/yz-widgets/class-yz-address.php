<?php

class YZ_Address_Info_Box extends YZ_Info_Box {
}