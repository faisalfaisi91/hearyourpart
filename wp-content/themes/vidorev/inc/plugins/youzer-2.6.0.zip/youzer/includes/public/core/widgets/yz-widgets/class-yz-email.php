<?php

class YZ_Email_Info_Box extends YZ_Info_Box {

}